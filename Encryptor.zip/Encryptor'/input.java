import java.util.Scanner;
/**
 * Write a description of class input here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class input
{
    // instance variables - replace the example below with your own
    private String name;
    private int birthday;

    /**
     * Constructor for objects of class input
     */
    public input()
    {
        // initialise instance variables
        name = " ";
        birthday = "-1";

    }

    //main method
    public static void main(String[]args)
    {
   //Creates Scanner object for user input
   Scanner scan = new Scanner (System.in);
   //Prompts the user for his name
   System.out.println("Please insert your first name:");
   //Stores the String entered by the user
   name = scan.next();
   //Prompts the user for his birthday
   System.out.println("Please insert the day you were born on. E.g. if you were born on 5th July, just enter '5'. ");
   birthday = scan.nextInt();
   
  
   
 }
